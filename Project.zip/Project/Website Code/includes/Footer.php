<style>
footer {
  position: fixed;
  bottom: 0;
  left: 0;
  height: 35px;
  background-color: #008080;
  color: white;
  width: 100%;
}
    tab1 { padding-left: 10em; }
    </style>

<footer class ="footer">
       <p>&copy;  <b>Kyle ART</b> | Wilmington, NC | Phone: (910-111-1111) | E-mail: Manager@artGallery.com | Website &copy;copyRights: SmoothOperators</a></p>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</html>
